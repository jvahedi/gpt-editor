***GPT Word Editor, by JOHN VAHEDI 7/29/2023***

Purpose:

 This executable will call GPT to edit your document and merge
 those edits as native suggestions. 

Prerequisites:
 Must have python preinstalled on your machine. If you do not have
 it on here, you can run the keyword "python" in your command 
 prompt and it should redirect you to the Microsoft Store for a 
 quick install.

Instructions:

### AT THIS TIME NOT SUPPORTED FOR MAC ###

Try to find a virtual machine to run windows on and try there. 