# ***GPT Word Editor***
***by John Vahedi 7/29/2023***

## Purpose:

 This executable will call GPT to edit your document and merge
 those edits as native suggestions. 

## Prerequisites:

 Must have python preinstalled on your machine. If you do not have
 it on here, you can run the keyword "python" in your command 
 prompt and it should redirect you to the Microsoft Store for a 
 quick install.

## Instructions:

***AT THIS TIME NOT SUPPORTED FOR MAC DIRECTLY. Instead...***

find a virtual machine to run Windows on:

1. Log on to Zed or any other RAND hosted Windows Server machines. 

2. Access the zip or files there locally. 
   Include as many documents in ".docx" format as you like by 
   dropping them into the "Windows" folder within "EditorBot."
   Update config.txt file with your own personal key. 

3. In the search bar, look for and run "Anconda Powershell Prompt."
   Navigate to the files' directory within this command line.
   (Hint: use 'cd ~' to locate your home directory.)

4. Type in "ClickMe.bat" and press enter. The edited files should
   appear in under 30 seconds. 

