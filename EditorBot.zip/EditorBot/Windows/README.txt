# ***GPT Word Editor***
***by John Vahedi 7/29/2023***

## Purpose:

 This executable will call GPT to edit your document and merge
 those edits as native suggestions. 

## Prerequisites:

 Must have python preinstalled on your machine. If you do not have
 it on here, you can run the keyword "python" in your command 
 prompt and it should redirect you to the Microsoft Store for a 
 quick install.

## Instructions:

1. Read this Document. 
- [ ] (NICE!!!)

2. Drop as many Microsoft Word Documents in this folder as needed.
- [ ] (A) The file must be in a ".docx" format.
- [ ] (B) Please keep document length under 2 pages at this time.

3. Open the Config.txt file:
- [ ] (A) paste in your own personal access key value.(IMPORTANT)
- [ ] (B) you can also change other parameters here as well. 
	

4. Double click the obvious "ClickMe.bat" file, and Presto! 
- [ ] Wait while a new edited file appears in the same directory. 
- [ ] Should take less than 30 seconds. 